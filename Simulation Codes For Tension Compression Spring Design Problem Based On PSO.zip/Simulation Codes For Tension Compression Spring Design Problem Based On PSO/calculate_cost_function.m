function op = calculate_cost_function(particle,i)
 x= particle(i).position;
 
 op = (x(3)+2)*x(2)*x(1)^2;

end