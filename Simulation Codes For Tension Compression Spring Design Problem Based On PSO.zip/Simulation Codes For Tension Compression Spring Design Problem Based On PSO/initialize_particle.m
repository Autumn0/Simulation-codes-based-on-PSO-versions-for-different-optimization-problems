function op = initialize_particle(pop_size,min_range,max_range,vmax,vmin)
          
for i = 1 : pop_size
    for j = 1 : length(min_range)
       particle(i).velocity(j) = rand * (vmax - vmin) + vmin;
       particle(i).position(j) = rand * (max_range(j) - min_range(j)) + min_range(j);
    end
end

op = particle;
end