function [final_cost final_solution final_cost_curve] = TVPSO(pop_size,maxit,nvar,min_range,max_range,vmax,vmin)



%%% initial values of the three main control parameters of each particle
wmax = 0.9;
wmin = 0.5;
c1s = 3;
c1f = 1;
c2s = 1;
c2f = 3;


%%% initialize the position and velocity of each particle
 particle = initialize_particle(pop_size,min_range,max_range,vmax,vmin); 

 
%%% calculate the violation value, fitness value, the personal best of each
%%% particle, as well as the initial values of the three control parameters of
%%% each particle at the initial step
for  i = 1 : pop_size
    particle(i).violation = calculate_violation(particle,i);
    particle(i).cost = calculate_cost_function(particle,i);
    particle(i).best.position = particle(i).position;
    particle(i).best.cost = particle(i).cost;
    particle(i).best.violation = particle(i).violation;

    particle(i).w = wmax;
    particle(i).c1 = c1s;
    particle(i).c2 = c2s;
    
end


%%% calculate the initial value of the relaxation variable of each particle
%%% at the initial iteration
mu = calculate_initial_relaxation(particle);

%% determine the information of the global best position of swarm at the initial iteration
gbest.cost = particle(1).cost;
gbest.position = particle(1).position;
gbest.violation = particle(1).violation;
gbest = updategbest(particle,gbest);



%% the main loop of the evolution
for it = 1 : maxit
    ff = 0;  %% initial value of the feasible particles
    
    for i = 1 : pop_size  %%% update the velocity and position of each particle at each iteration
        particle(i).velocity = particle(i).w * particle(i).velocity ... 
                             + particle(i).c1 * rand * (particle(i).best.position - particle(i).position) ...
                             + particle(i).c2 * rand * (gbest.position -  particle(i).position);
        particle(i).position = particle(i).position + particle(i).velocity;
       
    %%%%% modify position of each particle based on the saturation strategy
      for j = 1 : nvar
        if particle(i).position(j) < min_range(j)
            particle(i).position(j) = min_range(j);
        elseif particle(i).position(j) > max_range(j)
            particle(i).position(j) = max_range(j);
        end
      end
      
      %%% calculate the violation value of each particle at each iteration
      particle(i).violation = calculate_violation(particle,i);
      
      if particle(i).violation < mu  %% determine the number of feasible particles at each iteration
           ff = ff + 1;
      end
      
      %%% calculate fitness
      particle(i).cost = calculate_cost_function(particle,i);
      
      particle(i).pbest = updatepbest(particle,i); %%% update pbest of particle i;
      
    end
    

    
    gbest = updategbest(particle,gbest); %% update gbest of the swarm
    
    mu = mu * (1- ff/pop_size);
    
    for i = 1 : pop_size
         particle(i).w = (wmax - wmin) * (maxit -it)/maxit + wmin;
         particle(i).c1 = (c1s - c1f) * (maxit -it)/maxit + c1f;
         particle(i).c2 = (c2s - c2f) * (maxit -it)/maxit + c2f;
    end
    
    cost_curve(it) = gbest.cost;
    
end

final_cost = gbest.cost;
final_solution=gbest.position;
final_cost_curve = cost_curve;

end

