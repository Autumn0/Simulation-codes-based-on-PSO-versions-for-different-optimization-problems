function op = updategbest(pop,gbest)
    
   npop = numel(pop);
   
   for i = 1 : npop
       if pop(i).violation < gbest.violation
               gbest.position = pop(i).position;
               gbest.cost = pop(i).cost;
               gbest.violation = pop(i).violation;
       elseif pop(i).violation == gbest.violation && pop(i).cost <= gbest.cost
               gbest.position = pop(i).position;
               gbest.cost = pop(i).cost;
               gbest.violation = pop(i).violation;
       end
   end
   
   op = gbest;
   
end