function [final_cost final_solution final_cost_curve] = CLPSO(pop_size,maxit,nvar,min_range,max_range,vmax,vmin)

 
c = 1.5;
wmax = 0.9;
wmin = 0.1;
lmax = 1;
lmin = 0.1;

particle = initialize_particle(pop_size,min_range,max_range,vmax,vmin); %%% initialize particles

for  i = 1 : pop_size
    particle(i).violation = calculate_violation(particle,i);
    particle(i).cost = calculate_cost_function(particle,i);
    particle(i).best.position = particle(i).position;
    particle(i).best.cost = particle(i).cost;
    particle(i).best.violation = particle(i).violation;
    
    particle(i).w = wmax;
    particle(i).c = c;
    
end

mu = calculate_initial_relaxation(particle);
gbest.cost = particle(1).cost;
gbest.position = particle(1).position;
gbest.violation = particle(1).violation;
gbest = updategbest(particle,gbest);


for it = 1 : maxit
    ff = 0;  %% number of feasible solutions
    
    for i = 1 : pop_size
        
        %%% update the velocity of each particle
        l  = lmin + (lmax - lmin) * (exp(15*(i-1)/(pop_size-1))-1)/(exp(15)-1);
       for j = 1 : nvar
           t1 = rand;
           if l > t1
               particle(i).velocity(j) = particle(i).w *  particle(i).velocity(j) + particle(i).c * rand * (particle(i).best.position(j) - particle(i).position(j));
           else 
              particle(i).velocity(j) = particle(i).w *  particle(i).velocity(j) + particle(i).c * rand * (gbest.position(j) - particle(i).position(j));
           end
       end
        
       %% update the position of each particle
        particle(i).position = particle(i).position + particle(i).velocity;
       
    %%%%% modify position vector
      for j = 1 : nvar
        if particle(i).position(j) < min_range(j)
            particle(i).position(j) = min_range(j);
        elseif particle(i).position(j) > max_range(j)
            particle(i).position(j) = max_range(j);
        end
      end
      
      %%% calculate and violation
      particle(i).violation = calculate_violation(particle,i);
      if particle(i).violation < mu
           ff = ff + 1;
      end
      
      %%% calculate fitness
      particle(i).cost = calculate_cost_function(particle,i);
      
      particle(i).pbest = updatepbest(particle,i); %%% update pbest of particle i;
      
    end
    

    
    gbest = updategbest(particle,gbest); %% update gbest of the swarm
    
    mu = mu * (1- ff/pop_size);
    
    for i = 1 : pop_size  %%% update the inertia weight of each particle
         particle(i).w =  wmax - it/maxit * (wmax - wmin);
    end
    
    cost_curve(it) = gbest.cost;
    
end

final_cost = gbest.cost;
final_solution=gbest.position;
final_cost_curve = cost_curve;
end
