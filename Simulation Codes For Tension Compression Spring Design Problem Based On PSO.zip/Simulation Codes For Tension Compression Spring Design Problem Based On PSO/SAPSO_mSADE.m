function [final_cost final_solution final_cost_curve] =SAPSO_mSADE(pop_size,maxit,nvar,min_range,max_range,vmax,vmin)

top_number = fix(pop_size/4);

wmax = 0.9;
wmin = 0.1;
c1s = 2;
c1f = 0.1;
c2s = 0.1;
c2f = 2;

deta_w = (wmax - wmin)/maxit;
deta_c1 = (c1s - c1f)/maxit;
deta_c2 = (c2s - c2f)/maxit;


particle = initialize_particle(pop_size,min_range,max_range,vmax,vmin); %%% initialize particles

for  i = 1 : pop_size
    particle(i).violation = calculate_violation(particle,i);
    particle(i).cost = calculate_cost_function(particle,i);
    particle(i).best.position = particle(i).position;
    particle(i).best.cost = particle(i).cost;
    particle(i).best.violation = particle(i).violation;
    
    particle(i).w = wmax;
    particle(i).c1 = c1s;
    particle(i).c2 = c2s;
    
end

mu = calculate_initial_relaxation(particle);
gbest.cost = particle(1).cost;
gbest.position = particle(1).position;
gbest.violation = particle(1).violation;
gbest = updategbest(particle,gbest);

tic 
for it = 1 : maxit
    ff = 0;  %% number of feasible solutions
    
    for i = 1 : pop_size
        particle(i).velocity = particle(i).w * particle(i).velocity ... 
                             + particle(i).c1 * rand * (particle(i).best.position - particle(i).position) ...
                             + particle(i).c2 * rand * (gbest.position -  particle(i).position);
        particle(i).position = particle(i).position + particle(i).velocity;
       
    %%%%% modify position vector
      for j = 1 : nvar
        if particle(i).position(j) < min_range(j)
            particle(i).position(j) = min_range(j);
        elseif particle(i).position(j) > max_range(j)
            particle(i).position(j) = max_range(j);
        end
      end
      
      %%% calculate and violation
      particle(i).violation = calculate_violation(particle,i);
      if particle(i).violation < mu
           ff = ff + 1;
      end
      
      %%% calculate fitness
      particle(i).cost = calculate_cost_function(particle,i);
      
      particle(i).pbest = updatepbest(particle,i); %%% update pbest of particle i;
      
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
     temp = [];
      temp = sort_particle(particle);
      
 for i = 1 : pop_size
   cr = 0.5 + 0.1 * randn(1,nvar);
   off_spring1 = fix(rand * (top_number -1) + 1);
   while isequal(i,off_spring1)
      off_spring1 = fix(rand * (top_number -1) + 1);
   end
   off_spring2 = fix(rand * (top_number -1) + 1);
   while isequal(i,off_spring2) || isequal(off_spring1,off_spring2)
      off_spring2 = fix(rand * (top_number -1) + 1);
   end
   off_spring3 = fix(rand * (top_number -1) + 1);
   while isequal(i,off_spring3) || isequal(off_spring3,off_spring2) || isequal(off_spring3,off_spring1)
       off_spring3 = fix(rand * (top_number -1) + 1);
   end
   mutation = [];
   for j = 1 : nvar
      mutation.position(j) = temp(off_spring1).position(j) +  rand* 0.5 *(temp(off_spring2).position(j)-temp(off_spring3).position(j));
      if rand > cr(j)
         k = fix(rand * nvar);
         mutation.position(1:k) = particle(i).best.position(1:k);
      end
      if mutation.position(j) > max_range(j) 
         mutation.position(j) = 0.5 * (max_range(j) + mutation.position(j));
      elseif mutation.position(j) <min_range(j) 
         mutation.position(j) = 0.5 * (min_range(j) + mutation.position(j));
      end
   end
      mutation.violation = calculate_violation(mutation,1);
      mutation.cost = calculate_cost_function(mutation,1);    
     if mutation.violation < particle(i).best.violation
        particle(i).best.violation = mutation.violation;
        particle(i).best.position = mutation.position;
        particle(i).best.cost = mutation.cost;
     elseif mutation.violation == particle(i).violation && mutation.cost <= particle(i).best.cost
        particle(i).best.violation = mutation.violation;
        particle(i).best.position = mutation.position;
        particle(i).best.cost = mutation.cost;
     end
end

    
    gbest = updategbest(particle,gbest); %% update gbest of the swarm
    
    mu = mu * (1- ff/pop_size);
    
    for i = 1 : pop_size
        
        betam =  norm( particle(i).pbest.position - gbest.position );
        
        particle(i).w = (wmax - wmin) * exp( - deta_w * it/betam ) + wmin;
        particle(i).c1 = (c1s - c1f) * exp( - deta_c1 * it/betam ) + c1f;
        particle(i).c2 = (c2s - c2f) * exp( deta_c2 * it/betam ) + c2f;
        


       
    end
    
    cost_curve(it) = gbest.cost;
end

final_cost = gbest.cost;
final_solution=gbest.position;
final_cost_curve = cost_curve;

end
