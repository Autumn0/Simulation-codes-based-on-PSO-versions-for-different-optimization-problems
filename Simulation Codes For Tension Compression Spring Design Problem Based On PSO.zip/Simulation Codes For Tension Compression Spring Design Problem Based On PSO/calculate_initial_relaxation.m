function op = calculate_initial_relaxation(particle)
   sum = 0;
   for i = 1 : numel(particle)
       sum = sum + particle(i).violation;
   end
   op = sum /numel(particle);
end