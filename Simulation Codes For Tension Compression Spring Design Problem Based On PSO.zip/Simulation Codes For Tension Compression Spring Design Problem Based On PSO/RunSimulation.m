clear all;
close all;
clc;


pop_size = 40;  %% size of population
maxit = 500;  %% maximum iteration number


Nr = 10; % No. of Monte-Carlo experiment

vmax  = 3;  %% upper bound of particle's velocity
vmin = -3;  %% lower bound of particle's velocity


nvar = 3; %% number of variables
min_range = [0.05 0.25 2];
max_range = [2 1.3 15];


tic

for r=1:1:Nr
    % Run TVPSO
    [tvpso_final_cost{r} tvpso_final_solution{r} tvpso_cost_curve{r}] = TVPSO(pop_size,maxit,nvar,min_range,max_range,vmax,vmin);
     
    % Run SPSO_2011
    [spso2011_final_cost{r} spso2011_final_solution{r} spso2011_cost_curve{r}] = SPSO_2011(pop_size,maxit,nvar,min_range,max_range,vmax,vmin);
    
    % Run SAPSO_mSADE
    
    [sapso_msade_final_cost{r} sapso_msade_final_solution{r} sapso_msade_cost_curve{r}] = SAPSO_mSADE(pop_size,maxit,nvar,min_range,max_range,vmax,vmin);
    
    % Run FGIWPSO
    [fgiwpso_final_cost{r} fgiwpso_final_solution{r} fgiwpso_cost_curve{r}] = FGIWPSO(pop_size,maxit,nvar,min_range,max_range,vmax,vmin);
    
    % Run CLPSO
    [clpso_final_cost{r} clpso_final_solution{r} clpso_cost_curve{r}] = CLPSO(pop_size,maxit,nvar,min_range,max_range,vmax,vmin);
    
    % Run BBPSO
    [bbpso_final_cost{r} bbpso_final_solution{r} bbpso_cost_curve{r}] = BBPSO(pop_size,maxit,nvar,min_range,max_range,vmax,vmin);
end

toc

[tvpso_average_final_cost std_of_tvpso_final_cost] = calculate_average_solution_and_std(tvpso_final_cost);
tvpso_average_cost_curve = calculate_average_cost_curve(tvpso_cost_curve,maxit);

[spso2011_average_final_cost std_of_spso2011_final_cost] = calculate_average_solution_and_std(spso2011_final_cost);
spso2011_average_cost_curve = calculate_average_cost_curve(spso2011_cost_curve,maxit);

[sapso_msade_average_final_cost std_of_sapso_msade_final_cost] = calculate_average_solution_and_std(sapso_msade_final_cost);
sapso_msade_average_cost_curve = calculate_average_cost_curve(sapso_msade_cost_curve,maxit);

[fgiwpso_average_final_cost std_of_fgiwpso_final_cost] = calculate_average_solution_and_std(fgiwpso_final_cost);
fgiwpso_average_cost_curve = calculate_average_cost_curve(fgiwpso_cost_curve,maxit);

[clpso_average_final_cost std_of_clpso_final_cost] = calculate_average_solution_and_std(clpso_final_cost);
clpso_average_cost_curve = calculate_average_cost_curve(clpso_cost_curve,maxit);

[bbpso_average_final_cost std_of_bbpso_final_cost] = calculate_average_solution_and_std(bbpso_final_cost);
bbpso_average_cost_curve = calculate_average_cost_curve(bbpso_cost_curve,maxit);



figure(1)
plot(1:maxit,tvpso_average_cost_curve,'k--','linewidth',2)
hold on 
plot(1:maxit,spso2011_average_cost_curve,'r--','linewidth',2)
hold on 
plot(1:maxit,sapso_msade_average_cost_curve,'b--','linewidth',2)
hold on 
plot(1:maxit,fgiwpso_average_cost_curve,'y--','linewidth',2)
hold on 
plot(1:maxit,clpso_average_cost_curve,'g--','linewidth',2)
hold on
plot(1:maxit,bbpso_average_cost_curve,'p--','linewidth',2)



save('Monte_Carlo_Results_on_Tension_Compression_Spring_Design')

