function [final_cost final_solution final_cost_curve] = SPSO_2011(pop_size,maxit,nvar,min_range,max_range,vmax,vmin)

w = 1/(2*log(2));
c1 = 0.5 + log(2);
c2 = 0.5 + log(2);

particle = initialize_particle(pop_size,min_range,max_range,vmax,vmin); %%% initialize particles

for  i = 1 : pop_size
    particle(i).violation = calculate_violation(particle,i);
    particle(i).cost = calculate_cost_function(particle,i);
    particle(i).best.position = particle(i).position;
    particle(i).best.cost = particle(i).cost;
    particle(i).best.violation = particle(i).violation;
    
    particle(i).w = w;
    particle(i).c1 = c1;
    particle(i).c2 = c2;
    
end

mu = calculate_initial_relaxation(particle);
gbest.cost = particle(1).cost;
gbest.position = particle(1).position;
gbest.violation = particle(1).violation;
gbest = updategbest(particle,gbest);


for it = 1 : maxit
    
    ff = 0;  %% number of feasible solutions
     for i = 1 : pop_size
        % define a point p' on x-p, beyond p
        p_x_p = particle(i).best.position + particle(i).c1 * (particle(i).best.position - particle(i).position);
        % ... define a point g' on x-g, beyond g
        p_x_l = particle(i).position + particle(i).c2 * (gbest.position -  particle(i).position);
        
        % calculate the random point within the hyper-sphere
        sw = 1/3;
        G = sw * (particle(i).position + p_x_p + p_x_l);
    

        rad = norm(G - particle(i).position); % radius = Euclidean norm of x-G 
        if rad<1e-3
            rad=1e-3;
        end
        
        x_p = alea_sphere(nvar,rad)+ G; % Generate a random point in the hyper-sphere around G (uniform distribution)       
        particle(i).velocity = particle(i).w * particle(i).velocity  + x_p - particle(i).position; % Update the velocity = w*v(t) + (G-x(t)) + random_vector 
																					% The result is v(t+1)
        particle(i).position = particle(i).position + particle(i).velocity; % Apply the new velocity to the current position. The result is x(t+1)
     
     
         %%%%% modify position vector
      for j = 1 : nvar
        if particle(i).position(j) < min_range(j)
            particle(i).position(j) = min_range(j);
        elseif particle(i).position(j) > max_range(j)
            particle(i).position(j) = max_range(j);
        end
      end
      
      
      %%% calculate and violation
      particle(i).violation = calculate_violation(particle,i);
      if particle(i).violation < mu
           ff = ff + 1;
      end
      
      %%% calculate fitness
      particle(i).cost = calculate_cost_function(particle,i);
      
      particle(i).pbest = updatepbest(particle,i); %%% update pbest of particle i;
  
end
    gbest = updategbest(particle,gbest); %% update gbest of the swarm
    
    mu = mu * (1- ff/pop_size);
    
    cost_curve(it) = gbest.cost;
end
    

final_cost = gbest.cost;
final_solution=gbest.position;
final_cost_curve = cost_curve;
     
    end
      



















% tic 
% for it = 1 : maxit
%     
%     
%    
%        
%     %%%%% modify position vector
%    
%     
%       for j = 1 : nvar
%         if particle(i).position(j) < min_range(j)
%             particle(i).position(j) = min_range(j);
%         elseif particle(i).position(j) > max_range(j)
%             particle(i).position(j) = max_range(j);
%         end
%       end
%       
%       %%% calculate and violation
%       particle(i).violation = calculate_violation(particle,i);
%       if particle(i).violation < mu
%            ff = ff + 1;
%       end
%       
%       %%% calculate fitness
%       particle(i).cost = calculate_cost_function(particle,i);
%       
%       particle(i).pbest = updatepbest(particle,i); %%% update pbest of particle i;
%   
%     end
%     
%     gbest = updategbest(particle,gbest); %% update gbest of the swarm
%     
%     mu = mu * (1- ff/pop_size);
%     
%     cost_curve(it) = gbest.cost;
% end
% 
% final_cost = gbest.cost;
% final_solution=gbest.position;
% final_cost_curve = cost_curve;
% 
% end

