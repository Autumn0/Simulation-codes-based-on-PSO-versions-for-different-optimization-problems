function [final_cost final_solution final_cost_curve] = BBPSO(pop_size,maxit,nvar,min_range,max_range,vmax,vmin)





particle = initialize_particle(pop_size,min_range,max_range,vmax,vmin); %%% initialize particles

for  i = 1 : pop_size
    particle(i).violation = calculate_violation(particle,i);
    particle(i).cost = calculate_cost_function(particle,i);
    particle(i).best.position = particle(i).position;
    particle(i).best.cost = particle(i).cost;
    particle(i).best.violation = particle(i).violation;
    
    
end

mu = calculate_initial_relaxation(particle);
gbest.cost = particle(1).cost;
gbest.position = particle(1).position;
gbest.violation = particle(1).violation;
gbest = updategbest(particle,gbest);


for it = 1 : maxit
    ff = 0;  %% number of feasible solutions
    
    for i = 1 : pop_size
        
        data = [];
        gtemp = [];
        for j = 1 : nvar
           data(j) = norm( particle(i).best.position(j) - gbest.position(j));
           gtemp(j) = 0.5 * ( particle(i).best.position(j) + gbest.position(j));
           temp = rand;
         if temp < 0.3
           particle(i).position(j) = gtemp(j) + data(j) * rand;
         else
         particle(i).position(j) = particle(i).best.position(j);
         end
       end
       
       
    %%%%% modify position vector
      for j = 1 : nvar
        if particle(i).position(j) < min_range(j)
            particle(i).position(j) = min_range(j);
        elseif particle(i).position(j) > max_range(j)
            particle(i).position(j) = max_range(j);
        end
      end
      
      %%% calculate and violation
      particle(i).violation = calculate_violation(particle,i);
      if particle(i).violation < mu
           ff = ff + 1;
      end
      
      %%% calculate fitness
      particle(i).cost = calculate_cost_function(particle,i);
      
      particle(i).pbest = updatepbest(particle,i); %%% update pbest of particle i;
      
    end
    
    gbest = updategbest(particle,gbest); %% update gbest of the swarm
    mu = mu * (1- ff/pop_size);
    cost_curve(it) = gbest.cost;
    
end

final_cost = gbest.cost;
final_solution=gbest.position;
final_cost_curve = cost_curve;

end

