function [mean_fe_pso, psomean] = Calculate_Mean_Evolution(Nr,new_f1_PSO, FE1_PSO, evolution_f_PSO)


x1 = [];
y1 = [];
[x1 y1] = sort(new_f1_PSO);
for i = 1 : Nr
    sort_f1_pso(i) = new_f1_PSO(y1(i));
    sort_fe_pso(i) = FE1_PSO(y1(i));
    sort_evolution_of_pso{i} = evolution_f_PSO{y1(i)};
end


maxit = length(sort_evolution_of_pso{1});
for i = 1 : Nr
    if length(sort_evolution_of_pso{i}) > maxit
        maxit = length(sort_evolution_of_pso{i});
    end
end
 for k=1:Nr
    if (length( sort_evolution_of_pso{k})<maxit)
        templen = length( sort_evolution_of_pso{k});
         sort_evolution_of_pso{k}(length( sort_evolution_of_pso{k})+1:maxit) = sort_evolution_of_pso{k}(templen);
    end
 end
for j=1:maxit
    meanVal = 0;
    iter = 0;
    for k=1:Nr
        meanVal = meanVal + sort_evolution_of_pso{k}(j);    
      iter = iter + sort_fe_pso(k);
    end
      psomean(j) = meanVal/Nr;
end
 mean_fe_pso = iter/Nr;


end