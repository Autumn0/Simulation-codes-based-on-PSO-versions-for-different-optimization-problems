function SR = Calculate_SR(err,best_x)

  N = length(best_x);
  SR = 0;
  
  for i = 1 : N
      if best_x (i) <= err
          SR = SR + 1/N;
      end
  end
end