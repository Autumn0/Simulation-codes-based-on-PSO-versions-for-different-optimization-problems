function op = sort_particle(pop1)
 
  pop = pop1;
  npop = numel(pop);
for i = 1 : npop;
       pop(i).best.dominated_number = 1;
end
   
 for i = 1 : npop
     for j = 1 : i-1
         if pop(i).best.cost < pop(j).best.cost
             pop(j).best.dominated_number = pop(j).best.dominated_number + 1;
         end
     end
 end
 

 
 for i = 1 : npop
   temp(i) =  pop(i).best.dominated_number;
 end
[x y] = sort(temp);   %% sort solutions according to the fitness value of each particle

temppop = [];

 for i = 1 : npop
      temppop(i).position =  pop(y(i)).best.position;
      temppop(i).cost = pop(y(i)).best.cost;
      temppop(i).dominated_number = pop(y(i)).best.dominated_number;
 end
 
 op = temppop;

   
end