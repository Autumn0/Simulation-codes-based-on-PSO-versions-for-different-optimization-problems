function [best_x, max_FEs, evolution_f] = PSO_DE(N,D, FE_max, fun, err, LB, UB, opt_f,normalize,Nr)
%function [best_x] =SAPSO_mSADE(N,D, FE_max, fun, err, LB, UB, opt_f,normalize,Nr)

top_number = fix(N/4);

evolution_f = [];
best_x =[];
max_FEs=[];


wmax = 0.9;
wmin = 0.4;
c1s = 2;
c1f = 0.1;
c2s = 0.1;
c2f = 2;

deta_w = (wmax - wmin)/FE_max;
deta_c1 = (c1s - c1f)/FE_max;
deta_c2 = (c2s - c2f)/FE_max;


%% set the demensions of the position and velocity vectors of each particle
%% as well as inilialize the three control parameters of each particle
for i = 1 : N  
   particle(i).position = zeros(1,D);
   particle(i).velocity = zeros(1,D);
   
   particle(i).w = wmax;
   particle(i).c1 = c1s;
   particle(i).c2 = c2s;
end

if (normalize>0) %% set the boundaries of each dimension of the position vector of each particle based on the value of normalize
    xMin=0;
    xMax=1;
end

%Initialize the position and velocity vectors of each particles in
for i=1:1:N
    for j=1:1:D
        if (normalize==0)
            xMin=LB(j);
            xMax=UB(j); 
        end
        particle(i).position (j) = alea(xMin,xMax);
        particle(i).velocity (j) = alea(xMin - particle(i).position(j), xMax-particle(i).position(j));  
    end
end


% calculate fitness value of each particle at the initial iteration
for i = 1:1:N
    if (normalize>0) 
      particle(i).cost  = func( (particle(i).position * (UB - LB) + LB), fun,opt_f);  
    else
          particle(i).cost = func( particle(i).position ,fun,opt_f);
    end 
end

% initialize the personal best position of each particle
for i = 1 : N
    particle(i).best.position =  particle(i).position;
    particle(i).best.cost = particle(i).cost;
end

%%% determine the global best solution of the swarm at the initial
%%% iteration
gbest.cost = particle(1).cost;
gbest.position = particle(1).position;
gbest = updategbest(particle,gbest);



FEs = 0 ;
stop = 0;  % the flag value to determine whether the main loop of the evolution exists or not
it = 0; 

%main loop of PSO
 while stop <1
     
     for i = 1:1:N  % Update the position and velocity vectors of each particle
        particle(i).velocity = particle(i).w * particle(i).velocity ... 
                             + particle(i).c1 * rand * (particle(i).best.position - particle(i).position) ...
                             + particle(i).c2 * rand * (gbest.position -  particle(i).position);
        particle(i).position = particle(i).position + particle(i).velocity;
     
     
      %Check for constraint violations
        for j = 1:1:D
            if (normalize==0)
                xMin=LB(j);
                xMax=UB(j); 
            else
                xMin = 0;
                xMax = 1;
            end      

            if particle(i).position (j) > xMax
                particle(i).position (j) = xMax;
                particle(i).velocity(j)= -0.5 * particle(i).velocity(j); % variant: 0
            end

            if particle(i).position (j) < xMin
                particle(i).position (j) = xMin;
                particle(i).velocity(j) = -0.5 * particle(i).velocity(j); % variant: 0
            end   
        end %j
        
 
     
% calculate fitness value of each particle at each iteration
    if (normalize>0) 
      particle(i).cost  = func( (particle(i).position * (UB - LB) + LB), fun,opt_f);  
    else
      particle(i).cost = func( particle(i).position ,fun,opt_f);
    end

    
 %%% update pbest of particle i;
     particle(i).pbest = updatepbest(particle,i); 
     end
     
 %% evolve the personal best experimence of each particle based on DE    
 temp = [];
 temp = sort_particle(particle);     
 for i = 1 : N
     
   cr = 0.5 + 0.1 * randn(1,D);
   off_spring1 = fix(rand * (top_number -1) + 1);
   
   while isequal(i,off_spring1)
      off_spring1 = fix(rand * (top_number -1) + 1);
   end
   
   off_spring2 = fix(rand * (top_number -1) + 1);
   
   while isequal(i,off_spring2) || isequal(off_spring1,off_spring2) 
      off_spring2 = fix(rand * (top_number -1) + 1);
   end
   
   off_spring3 = fix(rand * (top_number -1) + 1);
   
   while isequal(i,off_spring3) || isequal(off_spring3,off_spring2) || isequal(off_spring3,off_spring1)
       off_spring3 = fix(rand * (top_number -1) + 1);
   end
   
   mutation = [];
   k= [];
   
   for j = 1 : D
      mutation.position(j) = temp(off_spring1).position(j) +  rand* 0.5 *(temp(off_spring2).position(j)-temp(off_spring3).position(j));
      if rand > cr(j)
         k = fix(rand * D);
         mutation.position(1:k) = particle(i).best.position(1:k);
      end
      if mutation.position(j) > UB(j) 
         mutation.position(j) = 0.5 * (UB(j) + mutation.position(j));
      elseif mutation.position(j) <LB(j) 
         mutation.position(j) = 0.5 * (LB(j) + mutation.position(j));
      end
   end
   
      
   if (normalize>0) 
      mutation.cost  = func( (mutation.position * (UB - LB) + LB), fun,opt_f);  
    else
          mutation.cost = func( mutation.position ,fun,opt_f);
   end 
    
   if  mutation.cost <= particle(i).best.cost
       particle(i).best.position = mutation.position;
       particle(i).best.cost = mutation.cost;
    end
 end
 
 
      

 gbest = updategbest(particle,gbest); %% update gbest of the swarm
  
 FEs = FEs + 1; %% the evalutaition calls of the evolution.  
 it = it + 1;
 
 %% check the exist condition of the evolution loop
 if (min (gbest.cost) < err)|| (FEs>=FE_max)
      stop=1;
 end 
  
 
  for i = 1 : N %% update the three control parameters of particles in each iteration.
    betam =  norm( particle(i).pbest.position - gbest.position ); 
    particle(i).w = (wmax - wmin) * exp( - deta_w * it/betam ) + wmin;
    particle(i).c1 = (c1s - c1f) * exp( - deta_c1 * it/betam ) + c1f;
    particle(i).c2 = (c2s - c2f) * exp( deta_c2 * it/betam ) + c2f; 
  end

 evolution_f = [evolution_f gbest.cost];
  
 end  % the end of the main loop
 










best_x = min(gbest.cost);
max_FEs = FEs;


end


