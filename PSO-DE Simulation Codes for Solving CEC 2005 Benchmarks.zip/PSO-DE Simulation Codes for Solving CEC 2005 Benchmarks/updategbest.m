function op = updategbest(pop,gbest)
    
   npop = numel(pop);
   
   for i = 1 : npop
       if  pop(i).cost <= gbest.cost
               gbest.position = pop(i).position;
               gbest.cost = pop(i).cost;
       end
   end
   
   op = gbest;
   
end