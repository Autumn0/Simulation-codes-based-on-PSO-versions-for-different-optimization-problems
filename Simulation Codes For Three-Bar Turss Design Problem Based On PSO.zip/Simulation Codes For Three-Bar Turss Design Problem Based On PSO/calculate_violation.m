function op = calculate_violation(particle,i)
   x = particle(i).position;
   
    p =2;
    data = 2;

    g_1 = (sqrt(2)*x(1)+x(2))/(sqrt(2)*x(1)^2 + 2*x(1)*x(2))* p -data;
    g_2 = x(2)/(sqrt(2)*x(1)^2+2*x(1)*x(2))*p - data;
    g_3 = 1/(sqrt(2)*x(2)+x(1))*p - data;

    op =  max(0,g_1) + max(0,g_2) + max(0,g_3);
end