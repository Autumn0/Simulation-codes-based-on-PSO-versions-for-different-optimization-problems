function [average_solution standard_deviation] = calculate_average_solution_and_std(final_cost)

Nr = length(final_cost);
cost_sum = [];
for r = 1 : Nr
    cost_sum(r)= final_cost{r};
end
    average_solution = mean(cost_sum);
    standard_deviation = std(cost_sum);

end