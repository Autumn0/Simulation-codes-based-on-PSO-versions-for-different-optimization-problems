function op = select_three_individuals(pop1,index)
  pop = [];
  pop = pop1;
  
  npop = numel(pop);
for i = 1 : npop;
       pop(i).best.dominated_number = 1;
end
   
 for i = 1 : npop
     for j = 1 : i-1
         if pop(i).best.infeasible_path_segment > pop(j).best.infeasible_path_segment
             pop(i).best.dominated_number = pop(i).best.dominated_number + 1;
         elseif pop(i).best.infeasible_path_segment < pop(j).best.infeasible_path_segment
              pop(j).best.dominated_number = pop(j).best.dominated_number + 1;
         elseif pop(i).best.infeasible_path_segment == pop(j).best.infeasible_path_segment && pop(i).best.cost > pop(j).best.cost
              pop(i).best.dominated_number = pop(i).best.dominated_number + 1;
         elseif pop(i).best.infeasible_path_segment == pop(j).best.infeasible_path_segment && pop(i).best.cost < pop(j).best.cost
             pop(j).best.dominated_number = pop(j).best.dominated_number + 1;
         end
     end
 end
 
%  for i = 1 : npop
%       temppop(i).infeasible_path_segment = pop(i).infeasible_path_segment;
%       temppop(i).xcoordinate =  pop(i).xcoordinate;
%       temppop(i).ycoordinate =  pop(i).ycoordinate;
%       temppop(i).pathlength = pop(i).pathlength;
%       temppop(i).threatcost = pop(i).threatcost;
%       temppop(i).cost = pop(i).cost;
%       %temppop(i).dominated_number = pop(y(i)).dominated_number;
%       temppop(i).selection_probability = (npop - pop(i).dominated_number)/npop;
%  end
%  
 
 for i = 1 : npop
   temp(i) =  pop(i).best.dominated_number;
 end
[x y] = sort(temp);   %% sort solutions according to infeasible path segement of each solution

% temppop = [];
% 
%  for i = 1 : npop
%       temppop(i).best.infeasible_path_segment = pop(y(i)).best.infeasible_path_segment;
%       temppop(i).best.xcoordinate =  pop(y(i)).best.xcoordinate;
%       temppop(i).best.ycoordinate =  pop(y(i)).best.ycoordinate;
%       %temppop(i).best.pathlength = pop(y(i)).best.pathlength;
%      % temppop(i).threatcost = pop(y(i)).threatcost;
%       temppop(i).cost = pop(y(i)).best.cost;
%       %temppop(i).dominated_number = pop(y(i)).dominated_number;
%       temppop(i).selection_probability = (npop - pop(y(i)).best.dominated_number)/npop;
%  end
 
 %op = temppop;

   op(1).number = y(1);
   op(1).xcoordinate = pop(y(1)).best.xcoordinate;
   op(1).ycoordinate = pop(y(1)).best.ycoordinate;
   
   op(2).number = y(2);
   op(2).xcoordinate = pop(y(2)).best.xcoordinate;
   op(2).ycoordinate = pop(y(2)).best.ycoordinate;
   
   op(3).number = y(3);
   op(3).xcoordinate = pop(y(3)).best.xcoordinate;
   op(3).ycoordinate = pop(y(3)).best.ycoordinate;
   
    

    if op(1).number == index
        op(1).number = 4;
        op(1).xcoordinate = pop(y(4)).best.xcoordinate;
        op(1).ycoordinate = pop(y(4)).best.ycoordinate;
    elseif op(2).number == index
        op(2).number = 4;
        op(2).xcoordinate = pop(y(4)).best.xcoordinate;
        op(2).ycoordinate = pop(y(4)).best.ycoordinate;
    elseif op(3).number == index
        op(3).number = 4;
        op(3).xcoordinate = pop(y(4)).best.xcoordinate;
        op(3).ycoordinate = pop(y(4)).best.ycoordinate;
    end
   
   
end