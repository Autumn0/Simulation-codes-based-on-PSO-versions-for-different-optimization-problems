function op = calculate_average_cost_curve (cost_curve,maxit)
    
Nr = length(cost_curve);
sum_cost = [];

% for i = 1 : maxit
%    for r =1 : Nr
%     
%       sum_cost(i) = sum_cost(i) + cost_curve{Nr,i};
%    end
% end
% 
% temp_cost =[];
% 
% for i = 1 : maxit
%     temp_cost(i) = sum_cost(i)/Nr;
% end


   for r =1 : Nr
      sum_cost(r,:) = cost_curve{r};
   end

  temp_cost =[];
  for i = 1 : maxit
      temp_cost(i) = mean( sum_cost (:,i));
  end


op = temp_cost;


end