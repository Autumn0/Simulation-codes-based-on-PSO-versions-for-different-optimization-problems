function op = calculate_cost_function(particle,i)
 x= particle(i).position;
 
 op = (2*sqrt(2)*x(1)+x(2))* 100;

end