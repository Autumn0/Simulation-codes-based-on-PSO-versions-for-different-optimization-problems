function op = updatepbest(pop,index)
       
       if pop(index).violation < pop(index).best.violation 
             pop(index).best.violation = pop(index).violation;
             pop(index).best.position = pop(index).position;
             pop(index).best.cost = pop(index).cost ;
             
       elseif pop(index).violation == pop(index).best.violation && pop(index).cost <=  pop(index).best.cost
             pop(index).best.violation = pop(index).violation;
             pop(index).best.position = pop(index).position;
             pop(index).best.cost = pop(index).cost ;
       end
       
       op = pop(index).best;
end